package ca.uregina.ahmed35m.ENSE475Lab1;

import java.util.ArrayList;

/**
 * @author ahmed35m
 * @version Build 1.0 27 January 2018
 * <p> CoffeeMaker.java 
 */

public class CoffeeMaker extends java.lang.Object{

	public static int MAX_INVENTORY = 100;
	public static int MAX_NUM_RECIPES= 100;
	private ArrayList<Recipe> Recipe = new ArrayList<Recipe>();
	private Inventory inventory = new Inventory  ();
	private ArrayList<Inventory> additionalInv = new ArrayList<Inventory>();
	private int numRecipes ;
	
	/**
	 * Constructor for CoffeeMaker
	 */
	public CoffeeMaker() {		
	}
		
	
	/**
	 * This function adds a Recipe object to CoffeMaker in its list of recipes
	 * @param rAdd Recipe object to be added
	 * @return Returns true if the Recipe is added or false if not
	 */
	public boolean addRecipe(Recipe rAdd)
	{

	if ( Recipe.size() <MAX_NUM_RECIPES)
		{
		Recipe.add(rAdd);
		return true;
		}
	else
		return false;
	}
	
	/**
	 * Returns the Recipe object if found in the recipe list 
	 * @param recipeName Name of the recipe to get
	 * @return Returns true if a recipe with the given name is found, else returns false
	 */
	public Recipe getRecipe(String recipeName)
	{
		Recipe r = null;
		
		if ( Recipe.size()>0)
		{
			for (int i = 0; i<Recipe.size(); i++)
			{
				if ( recipeName == Recipe.get(i).getRecipeName())
				{
					r=  Recipe.get(i);
				}
			}
			
		}
		return r;
		
	}
	
	
	/**
	 * Deletes the given recipe from the list of recipes in CoffeeMaker
	 * @param recipeName Name of the recipe to delete
	 * @return	Returns true if a recipe with the given name is deleted, else returns false
	 */
	public boolean deleteRecipe(String recipeName)
	{
		if ( Recipe.size()>0)
		{
			for (int i = 0; i<Recipe.size(); i++)
			{
				if ( recipeName == Recipe.get(i).getRecipeName())
				{
					Recipe.remove(i);
					System.out.printf("Removed"+ "\n");
					return true;
				}
			}
			
		}
		return false;	
	}
	
	
	/**
	 * Makes a coffee with the name of provided recipe if there are enough ingredients in the inventory
	 * @param recipeName Name of the recipe to make 
	 * @return Returns true if coffee is made successfully, else returns false
	 */
	public boolean makeCoffee(String recipeName)
	{
		boolean result = false;  // default value
		
		// first check the recipe list has anything to look for
		if ( Recipe.size()>0)
		{
			for (int i = 0; i<Recipe.size(); i++)  // find the recipe
			{
				if ( recipeName == Recipe.get(i).getRecipeName())  // recipe found
				{	
					System.out.println("recipe found"+ "\n");
					if (checklevels(Recipe.get(i)) == true)			// check if there enough resources
					{
						changelevels(Recipe.get(i));				// make coffee
						result = true;
					}
				
				}
				else
					System.out.println("Recipe NOT found"+ "\n");
			}
		}
		else
			result = false;
		
		
		
		return result;
	}

	/**
	 * Adjusts the sugar, milk and coffee quantity in Inventory by the given recipe
	 * @param r Recipe object provided to reduce the inventory by
	 */
	private void changelevels(Recipe r)
	{
		if (checklevels(r) )
		{
			inventory.setCoffee(inventory.getCoffee()-r.getCoffee());
			inventory.setSugar(inventory.getSugar()-r.getSugar());

			inventory.setMilk(inventory.getMilk()-r.getMilk());
		}
	}
	
	
	/**
	 * Checks the inventory levels against the recipe requirements to determine if a coffee can be made
	 * @param r Recipe object to make
	 * @return Returns true if enough sugar,milk and coffee levels are present in Inventory to make a coffee from the recipe, else false
	 */
	public boolean checklevels ( Recipe r)
	{
		
		boolean check = false;
		
		if (inventory.getCoffee()>=r.getCoffee() && inventory.getMilk()>=r.getMilk() && inventory.getSugar()>=r.getSugar())
		{
			check=true;
			System.out.println("There is enough ingredients in the inventory");
		}
		else
		{
			System.out.println("NOT enough ingredients in the inventory");

		}
			
		return check;
	}
	/**
	 * Gets the Inventory object in the CoffeeMaker
	 * @return Inventory object of the CoffeeMaker
	 */
	public Inventory getInventory()
	{
		return inventory;
	}
	
	
	
	
	/**
	 * Gets the ArrayList of Recipes in the CoffeeMaker
	 * @return Recipe
	 */
	public ArrayList<Recipe> getRecipe() {
		return Recipe;
	}

	/**
	 * Setter for Recipe (ArrayList) of CoffeeMaker 
	 * @param Recipe the Recipe to set
	 */
	public void setRecipe(ArrayList<Recipe> Recipe) {
		this.Recipe = Recipe;
	}

	
	public int getNumRecipes() {
		numRecipes = Recipe.size();
		return numRecipes;
	}

	public boolean editRecipe(Recipe recipe)
	{
		boolean r = false;
		//TODO
		for( int i=0; i<Recipe.size();i++)
		{
			//find Recipe to edit
			if ( Recipe.get(i).getRecipeName()==recipe.getRecipeName())
			{
				 Recipe.get(i).setCoffee(recipe.getCoffee());
				 Recipe.get(i).setSugar(recipe.getSugar());
				 Recipe.get(i).setMilk(recipe.getMilk());
				 //Recipe,get(i).setComponent(recipe.getComponentName(),recipe.getComponent() ;)
				 r= true;
			}
		}
		return r;
	}
	public boolean addInventory(Inventory newinventory)
	{
		//TODO
		if (additionalInv.size() < MAX_INVENTORY)
		{
			additionalInv.add(newinventory);
			return true;
		}
		else
		{
		return false;}
	}
	

	/**
	 * main function to simulate CoffeeMake
	 * <p>
	 * First Create a CoffeeMaker object
	 * <p>
	 * Create Recipe objects with a name(string), sugar value(int), coffee value(int), milk value(int)
	 * <p> 
	 * Add Recipe objects to the CoffeeMaker
	 * <p> You can now make a coffee
	 * 
	 * @param Recipe the Recipe to set
	 */
	public static void main(String[] args) {
		
		CoffeeMaker Brewster = new CoffeeMaker();
/// create recipes
		InventoryAdditional  a =new InventoryAdditional();
			Brewster.addInventory(a);
		
		
	
		
	}

}
