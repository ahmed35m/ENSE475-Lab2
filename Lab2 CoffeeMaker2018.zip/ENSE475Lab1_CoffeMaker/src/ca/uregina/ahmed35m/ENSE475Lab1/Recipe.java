package ca.uregina.ahmed35m.ENSE475Lab1;
/**
 * @author ahmed35m
 * @version Build 1.0 27 January 2018
 * <p> Recipe.java 
 */


/*
 * Recipe class contains ingredients quantity to make a coffee 
 * 
 */
public class Recipe {
	
	private int milk;
	private int sugar;
	private int coffee;
	private int expresso;
	private int cinammon;
	private int coco;
	private int syrup;
	private String recipeName;
	
	/**
	 * Construct for the Recipe object
	 * @param Name	Name of the recipe
	 * @param milkLevel	Milk quantity required for the recipe
	 * @param sugarLevel Sugar quantity required for the recipe
	 * @param coffeeLevel Coffee quantity required for the recipe
	 */
	public Recipe(String Name, int milkLevel, int sugarLevel, int coffeeLevel, int explevel, int cinmonlvl, int cocolvl, int syruplvl  ) 
	{
		recipeName = Name;
		milk = milkLevel;
		sugar =sugarLevel;
		coffee = coffeeLevel;
		expresso =  explevel;
		cinammon = cinmonlvl;
		coco = cocolvl;
		syrup = syruplvl;
				
	}

	/**
	 * Getter for the milk
	 * @return the milk
	 */
	public int getMilk() {
		return milk;
	}

	/**
	 * Setter for the milk
	 * <p>
	 * Value must be a positive integer
	 * @param milk the milk to set
	 */
	public void setMilk(int milk) {
		if( milk >0) {
		this.milk = milk;
		}
	}

	/**
	 * Getter for sugar
	 * @return the sugar
	 */
	public int getSugar() {
		return sugar;
	}

	/**
	 * Setter for the sugar
	 * <p>
	 * Value must be a positive integer
	 * @param sugar the sugar to set
	 */
	public void setSugar(int sugar) {
		if( sugar >0)
			{this.sugar = sugar;}
		
	}

	/**
	 * Getter for the coffee
	 * @return the coffee
	 */
	public int getCoffee() {
		return coffee;
	}

	/**
	 * Setter for the coffee
	 * <p>
	 * Value must be a positive integer
	 * @param coffee the coffee to set
	 */
	public void setCoffee(int coffee) {
		if (coffee>0)
			{this.coffee = coffee;}
	}

	/**
	 * Getter for the recipe name
	 * @return the recipeName
	 */
	public String getRecipeName() {
		return recipeName;
	}

	/**
	 * Setter for the recipe name
	 * @param recipeName the recipeName to set
	 */
	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public int getExpresso() {
		return expresso;
	}

	public int getCinammon() {
		return cinammon;
	}

	public int getCoco() {
		return coco;
	}

	public int getSyrup() {
		return syrup;
	}

	public void setExpresso(int expresso) {
		if ( expresso >0) { this.expresso = expresso;}
	}

	public void setCinammon(int cinammon) {
		if ( cinammon >0) {this.cinammon = cinammon;}
	}

	public void setCoco(int coco) {
		if ( coco >0) {this.coco = coco;}
	}

	public void setSyrup(int syrup) {
		if ( syrup >0) {this.syrup = syrup;}
	}
	
	

}


