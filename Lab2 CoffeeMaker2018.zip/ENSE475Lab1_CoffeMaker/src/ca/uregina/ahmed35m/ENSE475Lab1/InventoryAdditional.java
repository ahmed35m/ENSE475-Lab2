/**
 * 
 */
package ca.uregina.ahmed35m.ENSE475Lab1;

/**
 * @author ahmed35m
 *
 */
public class InventoryAdditional extends Inventory{
	
	InventoryAdditional()
	{
		componentName = "";
		componentQ=20;
	}
	
	private String componentName;
	public String getComponentName() {
		return componentName;
	}
	public int getComponentQ() {
		return componentQ;
	}
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
	public void setComponentQ(int componentQ) {
		this.componentQ = componentQ;
	}
	private int componentQ;
	
	
	
	

}
