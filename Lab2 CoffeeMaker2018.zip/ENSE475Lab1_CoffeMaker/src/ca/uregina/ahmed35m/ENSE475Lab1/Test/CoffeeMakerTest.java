/**
 * 
 */
package ca.uregina.ahmed35m.ENSE475Lab1.Test;

import static org.junit.Assert.*;

import org.junit.Test;

import ca.uregina.ahmed35m.ENSE475Lab1.CoffeeMaker;
import ca.uregina.ahmed35m.ENSE475Lab1.Inventory;
import ca.uregina.ahmed35m.ENSE475Lab1.Recipe;

/**
 * @author ahmed35m
 * @version 2.1.0 Build 27 January 2018
 *
 */
public class CoffeeMakerTest {

	/**
	 * Test method for {@link ca.uregina.ahmed35m.ENSE475Lab1.CoffeeMaker#CoffeeMaker()}.
	 * This tests if the CoffeeMaker object is created with correct levels of sugar,coffee and milk and no recipes
	 */
	@Test
	public void testCoffeeMaker() {
		CoffeeMaker Bru = new CoffeeMaker();

		assertEquals(20,Bru.getInventory().getCoffee());
		assertEquals(20,Bru.getInventory().getMilk());
		assertEquals(20,Bru.getInventory().getSugar());
		assertSame(0,Bru.getRecipe().size());
		
	}

	/**
	 * Test method for {@link ca.uregina.ahmed35m.ENSE475Lab1.CoffeeMaker#addRecipe(ca.uregina.ahmed35m.ENSE475Lab1.Recipe)}.
	 * This test if a recipe is added successfully to the CoffeeMaker
	 * The added recipe should retrievable and the size of recipe list should increase by 1
	 */
	@Test
	public void testAddRecipe() {
		CoffeeMaker Bru = new CoffeeMaker();
		Recipe rum  = new Recipe("Rum",5,5,1);
		assertTrue(Bru.addRecipe(rum));
		assertEquals(1,Bru.getRecipe().size());
		
	}

	/**
	 * Test method for {@link ca.uregina.ahmed35m.ENSE475Lab1.CoffeeMaker#getRecipe(java.lang.String)}.
	 * This test if the added recipe is retrievable
	 */
	@Test
	public void testGetRecipe() {
		CoffeeMaker Bru = new CoffeeMaker();
		Recipe rum  = new Recipe("Rum",5,5,1);
		Bru.addRecipe(rum);
		assertSame(rum,Bru.getRecipe("Rum"));
		assertSame("Rum",Bru.getRecipe().get(0).getRecipeName());
	}

	/**
	 * Test method for {@link ca.uregina.ahmed35m.ENSE475Lab1.CoffeeMaker#deleteRecipe(java.lang.String)}.
	 * This tests if a recipe present in the recipe list of CoffeeMaker is deletable 
	 */
	@Test
	public void testDeleteRecipe() {
		CoffeeMaker Bru = new CoffeeMaker();
		Recipe rum  = new Recipe("Rum",5,5,1);
		Bru.addRecipe(rum);
		assertTrue(Bru.deleteRecipe("Rum"));
		assertSame(0,Bru.getRecipe().size());
		assertFalse(Bru.deleteRecipe("vanilla"));
	}

	/**
	 * Test method for {@link ca.uregina.ahmed35m.ENSE475Lab1.CoffeeMaker#makeCoffee(java.lang.String)}.
	 * This tests if a coffee can be made from CoffeeMaker as long as there is enough inventory required by the recipe
	 */
	@Test
	public void testMakeCoffee() {
		CoffeeMaker Bru = new CoffeeMaker();
		Recipe rum  = new Recipe("Rum",5,5,5);
		Bru.addRecipe(rum);	
		Recipe coco  = new Recipe("Coco",0,0,1);
		Bru.addRecipe(coco);
		assertFalse(Bru.makeCoffee("mocha"));
		assertTrue(Bru.makeCoffee("Rum"));
		assertTrue(Bru.makeCoffee("Rum"));
		assertTrue(Bru.makeCoffee("Rum"));
		assertTrue(Bru.makeCoffee("Rum"));

		
		// The inventory should be empty
		assertFalse(Bru.makeCoffee("Coco"));
	}
	

	/**
	 * Test method for {@link ca.uregina.ahmed35m.ENSE475Lab1.CoffeeMaker#checklevels(ca.uregina.ahmed35m.ENSE475Lab1.Recipe)}.
	 * This methods check if the inventory levels for sugar,milk and coffee are enough to make the given recipe
	 * The levels are decreased and checked each time before making a coffee, after 1st coco 2nd coco cannot be made as there is not enough sugar,milk,coffee left
	 */
	@Test
	public void testChecklevels() {
		CoffeeMaker Bru = new CoffeeMaker();
		Recipe rum  = new Recipe("Rum",5,5,5);
		Bru.addRecipe(rum);	
		Recipe coco  = new Recipe("Coco",10,10,10);
		Bru.addRecipe(coco);
		
		Bru.makeCoffee("Rum");
		//Should have enough inventory level for a rum
		assertTrue(Bru.checklevels(rum) );
		
		//Should have enough inventory level for a coco
		assertTrue(Bru.checklevels(coco) );
		Bru.makeCoffee("Coco");
		
		//Should NOT have enough inventory level for a coco anymore

		assertFalse(Bru.checklevels(coco) );
		
		//Should have enough inventory level for a rum still

		assertTrue(Bru.checklevels(rum) );
		assertSame(5, Bru.getInventory().getCoffee());

	
	}
	
	
	/**
	 * Test method for {@link ca.uregina.ahmed35m.ENSE475Lab1.CoffeeMaker#editRecipe(ca.uregina.ahmed35m.ENSE475Lab1.Recipe)}.
	 * 
	 */
	@Test
	public void testeditRecipe() 
	{
		CoffeeMaker Bru = new CoffeeMaker();
		Recipe H  = new Recipe("H",15,15,20);
		
		//Case 1
		assertTrue(H.editRecipe("H",4,5,5,0,0));

		assertSame(4,H.getRecipe());
		
	}
	
	
	/**
	 * Test method for {@link ca.uregina.ahmed35m.ENSE475Lab1.CoffeeMaker#addInventory(ca.uregina.ahmed35m.ENSE475Lab1.Recipe)}.
	 */
	@Test
	public void testaddInventory()
	{
		CoffeeMaker Bru = new CoffeeMaker();
		Recipe H  = new Recipe("H",15,15,20);
		Bru.addRecipe(H);
		
		Inventory i1 = new Inventory();
		Inventory i2 = new Inventory();
		Inventory i3 = new Inventory();
		Inventory i4 = new Inventory();
		Inventory i5 = new Inventory();
		Inventory i6 = new Inventory();

		
		//Case 1 - able to add inventory
		assertTrue(Bru.addInventory(i1));
		
		//Case 2 - able to stop adding over max
		assertTrue(Bru.addInventory(i1));
		assertTrue(Bru.addInventory(i2));
		assertTrue(Bru.addInventory(i3));
		assertTrue(Bru.addInventory(i4));
		assertTrue(Bru.addInventory(i5));
		assertFalse(Bru.addInventory(i6));
		
		//Case 3 - the added inventory is function-able
		assertTrue(Bru.makeCoffee("H"));
		assertTrue(Bru.makeCoffee("H"));
		assertTrue(Bru.makeCoffee("H"));
		assertTrue(Bru.makeCoffee("H"));
		assertTrue(Bru.makeCoffee("H"));
		assertFalse(Bru.makeCoffee("H"));

		
		//Case 4 - Inventory stays in the list after functioning
		assertSame(6,Bru.getInventory().size());
		
	
	}
}



