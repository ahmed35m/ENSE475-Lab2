package ca.uregina.ahmed35m.ENSE475Lab1;
/**
 * @author ahmed35m
 * @version Build 1.0 27 January 2018
 * <p> Inventory.java 
 */


public class Inventory {
	private int milk;
	private int sugar;
	private int coffee;
	
	
	/**
	 * Construct for the Inventory object
	 * <p>
	 * Sets the milk, sugar and coffee level to 20 units
	 */
	public Inventory()
	{
	milk = sugar = coffee =20;
	}


	/**
	 * Gets milk level in CoffeeMaker 
	 * @return the milk
	 */
	public int getMilk() {
		return milk;
	}


	/**
	 * Setter for milk level in CoffeeMaker
	 * @param milk the milk level to set
	 */
	public void setMilk(int newmilk) {
		if (newmilk>=0) {
				this.milk = newmilk;
		}
	}


	/**
	 * Gets sugar level in CoffeeMaker 
	 * @return the sugar
	 */
	public int getSugar() {
		return sugar;
	}


	/**
	 * Setter for sugar level in CoffeeMaker
	 * @param sugar the sugar level to set
	 */
	public void setSugar(int newsugar) {
		if (newsugar>=0)
			{this.sugar = newsugar;}
	}


	/**
	 * Gets the coffee level in CoffeeMaker
	 * @return the coffee
	 */
	public int getCoffee() {
		return coffee;
	}


	/**
	 * Setter the coffee level in CoffeeMaker
	 * @param coffee the coffee to set
	 */
	public void setCoffee(int newcoffee) {
		if(newcoffee>=0)
		this.coffee = newcoffee;
	}
	
}
